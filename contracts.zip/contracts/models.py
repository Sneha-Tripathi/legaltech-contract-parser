from django.db import models
from django.contrib.auth.models import User


class Contract(models.Model):

    user = models.ForeignKey(
        User,
        on_delete=models.CASCADE,
        null=True,
        blank=True
    )

    title = models.CharField(
        max_length=255
    )

    uploaded_file = models.FileField(
        upload_to="contracts/"
    )

    uploaded_at = models.DateTimeField(
        auto_now_add=True
    )

    def __str__(self):
        return self.title


class ExtractedClause(models.Model):

    contract = models.ForeignKey(
        Contract,
        on_delete=models.CASCADE
    )

    clause_name = models.CharField(
        max_length=255
    )

    def __str__(self):
        return self.clause_name


class RiskFlag(models.Model):

    contract = models.ForeignKey(
        Contract,
        on_delete=models.CASCADE
    )

    risk_type = models.CharField(
        max_length=255
    )

    description = models.TextField()

    def __str__(self):
        return self.risk_type
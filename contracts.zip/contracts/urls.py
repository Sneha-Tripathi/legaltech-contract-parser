from django.urls import path
from . import views

urlpatterns = [
    path("", views.home, name="home"),

    path("upload/", views.upload_contract, name="upload"),

    path("dashboard/", views.dashboard, name="dashboard"),

    path("contracts/", views.contracts_list, name="contracts_list"),

    path(
        "result/<int:contract_id>/",
        views.result_view,
        name="result",
    ),

    path(
        "download/<int:contract_id>/",
        views.download_report,
        name="download_report",
    ),

    path(
        "delete/<int:contract_id>/",
        views.delete_contract,
        name="delete_contract",
    ),
]
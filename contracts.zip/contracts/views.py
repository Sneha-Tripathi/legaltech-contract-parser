from django.shortcuts import render, redirect, get_object_or_404
from django.http import HttpResponse
from django.contrib.auth.decorators import login_required
from django.contrib import messages

from reportlab.pdfgen import canvas

from .models import Contract, ExtractedClause, RiskFlag
from .utils import extract_text_from_pdf
from .analyzer import detect_clauses, detect_risks
from .queries import get_contract_with_details
from django.shortcuts import render

def home(request):
    return render(request, "home.html")

# ======================================================
# Upload Contract
# ======================================================

@login_required
def upload_contract(request):

    if request.method == "POST":

        title = request.POST.get("title")
        uploaded_file = request.FILES.get("file")

        if not title or not uploaded_file:

            return render(
                request,
                "contracts/upload.html",
                {
                    "error": "Please provide title and PDF file."
                }
            )

        contract = Contract.objects.create(
            user=request.user,
            title=title,
            uploaded_file=uploaded_file
        )

        text = extract_text_from_pdf(
            contract.uploaded_file.path
        )

        contract.extracted_text = text
        contract.save()

        clauses = detect_clauses(text)

        for clause in clauses:

            ExtractedClause.objects.create(
                contract=contract,
                clause_name=clause
            )

        risks = detect_risks(text)

        for risk in risks:

            RiskFlag.objects.create(
                contract=contract,
                risk_type="Detected Risk",
                description=str(risk)
            )

        messages.success(
            request,
            "Contract uploaded and analyzed successfully."
        )

        return redirect(
            "result",
            contract.id
        )

    return render(
        request,
        "contracts/upload.html"
    )


# ======================================================
# Result Page
# ======================================================

@login_required
def result_view(request, contract_id):

    contract = get_contract_with_details(contract_id)

    clauses = contract.extractedclause_set.all()

    risks = contract.riskflag_set.all()

    return render(
        request,
        "contracts/result.html",
        {
            "contract": contract,
            "clauses": clauses,
            "risks": risks
        }
    )


# ======================================================
# Dashboard
# ======================================================

@login_required
def dashboard(request):

    contracts_count = Contract.objects.filter(
        user=request.user
    ).count()

    clauses_count = ExtractedClause.objects.filter(
        contract__user=request.user
    ).count()

    risks_count = RiskFlag.objects.filter(
        contract__user=request.user
    ).count()

    recent_contracts = Contract.objects.filter(
        user=request.user
    ).order_by(
        "-uploaded_at"
    )[:5]

    return render(
        request,
        "contracts/dashboard.html",
        {
            "contracts_count": contracts_count,
            "clauses_count": clauses_count,
            "risks_count": risks_count,
            "recent_contracts": recent_contracts
        }
    )
# ======================================================
# Contracts List
# ======================================================

@login_required
def contracts_list(request):

    search = request.GET.get("search")

    contracts = Contract.objects.filter(
        user=request.user
    ).order_by("-uploaded_at")

    if search:

        contracts = contracts.filter(
            title__icontains=search
        )

    return render(
        request,
        "contracts/contracts_list.html",
        {
            "contracts": contracts,
            "search": search
        }
    )


# ======================================================
# Database Statistics
# ======================================================

@login_required
def database_stats(request):

    return render(
        request,
        "contracts/stats.html",
        {
            "total_contracts": Contract.objects.filter(
                user=request.user
            ).count(),

            "total_clauses": ExtractedClause.objects.filter(
                contract__user=request.user
            ).count(),

            "total_risks": RiskFlag.objects.filter(
                contract__user=request.user
            ).count(),
        }
    )


# ======================================================
# Download PDF Report
# ======================================================

@login_required
def download_report(request, contract_id):

    contract = get_object_or_404(
        Contract,
        id=contract_id,
        user=request.user
    )

    clauses = ExtractedClause.objects.filter(
        contract=contract
    )

    risks = RiskFlag.objects.filter(
        contract=contract
    )

    response = HttpResponse(
        content_type="application/pdf"
    )

    response[
        "Content-Disposition"
    ] = f'attachment; filename="{contract.title}_Report.pdf"'

    pdf = canvas.Canvas(response)

    width, height = 595, 842

    y = height - 50

    # ---------------- Heading ----------------

    pdf.setFont(
        "Helvetica-Bold",
        18
    )

    pdf.drawString(
        130,
        y,
        "LEGALTECH CONTRACT REPORT"
    )

    y -= 40

    pdf.setFont(
        "Helvetica",
        12
    )

    pdf.drawString(
        50,
        y,
        f"Contract Title : {contract.title}"
    )

    y -= 20

    pdf.drawString(
        50,
        y,
        f"Contract ID : {contract.id}"
    )

    y -= 20

    pdf.drawString(
        50,
        y,
        f"Uploaded : {contract.uploaded_at}"
    )

    y -= 40

    # ---------------- Clauses ----------------

    pdf.setFont(
        "Helvetica-Bold",
        14
    )

    pdf.drawString(
        50,
        y,
        "Detected Clauses"
    )

    y -= 25

    pdf.setFont(
        "Helvetica",
        12
    )

    if clauses.exists():

        for clause in clauses:

            pdf.drawString(
                70,
                y,
                f"• {clause.clause_name}"
            )

            y -= 20

            if y < 60:

                pdf.showPage()

                y = 800

                pdf.setFont(
                    "Helvetica",
                    12
                )

    else:

        pdf.drawString(
            70,
            y,
            "No Clauses Found"
        )

        y -= 20

    # ---------------- Risks ----------------

    y -= 20

    pdf.setFont(
        "Helvetica-Bold",
        14
    )

    pdf.drawString(
        50,
        y,
        "Risk Analysis"
    )

    y -= 25

    pdf.setFont(
        "Helvetica",
        12
    )

    if risks.exists():

        for risk in risks:

            pdf.drawString(
                70,
                y,
                f"Risk Type : {risk.risk_type}"
            )

            y -= 18

            pdf.drawString(
                90,
                y,
                f"Description : {risk.description}"
            )

            y -= 25

            if y < 60:

                pdf.showPage()

                y = 800

                pdf.setFont(
                    "Helvetica",
                    12
                )

    else:

        pdf.drawString(
            70,
            y,
            "No Risks Found"
        )

    # ---------------- Footer ----------------

    pdf.setFont(
        "Helvetica-Oblique",
        10
    )

    pdf.drawString(
        50,
        30,
        "Generated by LegalTech Contract Parsing Engine"
    )

    pdf.save()

    return response


# ======================================================
# Delete Contract
# ======================================================

@login_required
def delete_contract(request, contract_id):

    contract = get_object_or_404(
        Contract,
        id=contract_id,
        user=request.user
    )

    contract.delete()

    messages.success(
        request,
        "Contract deleted successfully."
    )

    return redirect(
        "contracts_list"
    )